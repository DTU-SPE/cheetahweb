#!/bin/bash          
echo Converting video files
FILES=./videos/*
architecture=$*'bit'

for file in $FILES
do
  echo "Processing $file file..."
  ./bin/$architecture/ffmpeg -i $file  ${file/avi/webm}
done
